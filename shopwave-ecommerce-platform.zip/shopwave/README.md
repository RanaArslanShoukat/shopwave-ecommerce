# Shopwave — Full-Stack E-Commerce Platform with Admin Dashboard (MERN)



A storefront where customers browse a catalog, check out with Stripe (test mode), and track orders — plus a separate admin panel for inventory, order management, and sales analytics.

## Stack
- **Backend:** Node, Express, MongoDB/Mongoose, Stripe, JWT
- **Frontend:** React (Vite), React Router, Tailwind CSS, Recharts, Axios

## What makes this non-trivial (not just a CRUD clone)
1. **Concurrency-safe inventory.** Stock is reserved atomically at checkout time using `findOneAndUpdate` with a `$gte` guard inside a MongoDB transaction — not a read-then-write in application code. Two customers racing for the last unit of a product: exactly one succeeds, the other gets a clear "out of stock" response immediately, instead of both being allowed to "buy" it and finding out later. See `backend/controllers/orderController.js`.
2. **Webhook-driven order state**, not client-trust. The Stripe webhook (`checkout.session.completed` / `checkout.session.expired`) is the only thing that ever marks an order `paid` or releases reserved stock back to inventory — the frontend's "success" page is just a courtesy message. See `backend/controllers/webhookController.js`.
3. **Real analytics**, not decoration. The admin dashboard's charts (revenue over time, top products, order status breakdown) are powered by MongoDB aggregation pipelines, not client-side math over a full order dump. See `backend/controllers/analyticsController.js`.

## Getting started

### 1. Backend
```bash
cd backend
cp .env.example .env
npm install
node seed.js        # creates an admin + customer account and sample products
npm run dev          # http://localhost:5000
```

**MongoDB transactions require a replica set** (used for the atomic stock reservation). MongoDB Atlas does this automatically, including on the free tier — just point `MONGO_URI` at your Atlas cluster. For local MongoDB, start it with `mongod --replSet rs0` and run `rs.initiate()` once in the mongo shell.

**Stripe test mode:**
1. Create a free Stripe account, switch to **test mode** (toggle in the dashboard).
2. Copy your test secret key into `STRIPE_SECRET_KEY`.
3. Install the [Stripe CLI](https://docs.stripe.com/stripe-cli) and run:
   ```bash
   stripe listen --forward-to localhost:5000/api/webhooks/stripe
   ```
   This prints a webhook signing secret (`whsec_...`) — put that in `STRIPE_WEBHOOK_SECRET`.
4. Test card: `4242 4242 4242 4242`, any future expiry, any CVC.

### 2. Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev          # http://localhost:5173
```

## Login
- Admin: `admin@example.com` / `admin123` → redirected to `/admin`
- Customer: `customer@example.com` / `customer123`

## Project structure
```
backend/
  models/        User, Product, Category, Order
  controllers/   productController (catalog + aggregation search), orderController
                 (checkout + atomic stock reservation), webhookController (Stripe events),
                 analyticsController (aggregation-based dashboard data)
  routes/        Express routers — note webhookRoutes is mounted with express.raw()
                 in server.js, BEFORE the global express.json()
  seed.js        Populates sample data
frontend/
  src/context/   AuthContext (JWT session), CartContext (localStorage cart)
  src/pages/     Home, ProductDetail, Cart, CheckoutSuccess/Cancel, Orders
  src/pages/admin/  AdminDashboard (Recharts), AdminProducts (CRUD), AdminOrders
```

## What's stubbed vs. production-ready
- **Images** are just URLs in the product form — no upload/CDN pipeline. Wire up Cloudinary/S3 the same way as any other file-upload flow if you want real image hosting.
- **Refunds/cancellations after payment** aren't implemented — only the pre-payment expiry path releases stock. A `POST /api/orders/:id/refund` route calling `stripe.refunds.create` plus a stock-restore would be the natural next step.
- **Email receipts** aren't sent. Stripe can do this automatically (enable "Email receipts" in the Stripe dashboard) without any code changes.

## Suggested next steps for a portfolio
1. Add Stripe refunds tied to an admin "Cancel Order" button.
2. Add a low-stock email/Slack alert triggered from `analyticsController.getSummary`'s `lowStockCount`.
3. Write a test that fires two concurrent checkout requests for a product with stock=1 and asserts exactly one succeeds — this is the single best way to *prove* the concurrency handling works, not just claim it.
