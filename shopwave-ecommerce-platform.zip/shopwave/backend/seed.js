// Run with: node seed.js
// Creates one admin user, a few categories, and a handful of products with stock,
// so the storefront and admin dashboard have something to show immediately.
const dotenv = require('dotenv');
dotenv.config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Category = require('./models/Category');
const Product = require('./models/Product');

const run = async () => {
  await connectDB();

  await Promise.all([User.deleteMany({}), Category.deleteMany({}), Product.deleteMany({})]);

  await User.create({ name: 'Admin', email: 'admin@example.com', password: 'admin123', role: 'admin' });
  await User.create({ name: 'Test Customer', email: 'customer@example.com', password: 'customer123', role: 'customer' });

  const categories = await Category.insertMany([
    { name: 'Electronics', slug: 'electronics' },
    { name: 'Home & Kitchen', slug: 'home-kitchen' },
    { name: 'Apparel', slug: 'apparel' },
  ]);

  await Product.insertMany([
    { name: 'Wireless Headphones', description: 'Over-ear, noise-cancelling, 30hr battery.', price: 89.99, category: categories[0]._id, stock: 25, sku: 'ELEC-001' },
    { name: 'Mechanical Keyboard', description: 'Hot-swappable switches, RGB backlight.', price: 129.0, category: categories[0]._id, stock: 15, sku: 'ELEC-002' },
    { name: 'Ceramic Pour-Over Set', description: 'Hand-glazed dripper + carafe.', price: 42.5, category: categories[1]._id, stock: 30, sku: 'HOME-001' },
    { name: 'Cast Iron Skillet', description: '12-inch, pre-seasoned.', price: 34.99, category: categories[1]._id, stock: 40, sku: 'HOME-002' },
    { name: 'Organic Cotton Hoodie', description: 'Unisex, midweight fleece.', price: 58.0, category: categories[2]._id, stock: 3, sku: 'APP-001' },
    { name: 'Merino Wool Socks (3-pack)', description: 'Moisture-wicking, cushioned sole.', price: 24.0, category: categories[2]._id, stock: 60, sku: 'APP-002' },
  ]);

  console.log('Seed complete. Admin login: admin@example.com / admin123');
  await mongoose.disconnect();
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
