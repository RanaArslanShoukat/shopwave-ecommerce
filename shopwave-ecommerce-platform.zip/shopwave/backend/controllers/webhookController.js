const stripe = require('../config/stripe');
const mongoose = require('mongoose');
const Order = require('../models/Order');
const Product = require('../models/Product');
const { releaseStock } = require('./orderController');

/**
 * Stripe webhook handler.
 *
 * Why a webhook and not just the success_url redirect? The redirect only
 * fires if the customer's browser makes it back to your site — it can fail
 * (closed tab, network drop, phone dies). The webhook is Stripe's own
 * server calling YOUR server directly, so it's the source of truth for
 * whether money actually moved. The frontend's success page just shows a
 * "thanks" message; this handler is what actually marks the order paid.
 *
 * The raw request body (not JSON-parsed) is required to verify the
 * signature — see server.js, where this route is mounted BEFORE
 * express.json() for that reason.
 */
const handleStripeWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const orderId = session.metadata.orderId;

      const order = await Order.findById(orderId);
      if (order && order.status === 'pending_payment') {
        order.status = 'paid';
        order.stripePaymentIntentId = session.payment_intent;
        await order.save();

        // Now that payment is confirmed, credit unitsSold for the admin analytics chart.
        // (Stock was already decremented at checkout time — see reserveStock.)
        for (const item of order.items) {
          await Product.findByIdAndUpdate(item.product, { $inc: { unitsSold: item.quantity } });
        }
      }
      break;
    }

    // Checkout page timed out or the customer navigated away without paying —
    // release the reserved stock back so it's sellable again.
    case 'checkout.session.expired': {
      const session = event.data.object;
      const orderId = session.metadata.orderId;

      const order = await Order.findById(orderId);
      if (order && order.status === 'pending_payment') {
        const mongoSession = await mongoose.startSession();
        try {
          await mongoSession.withTransaction(async () => {
            await releaseStock(order.items, mongoSession);
            order.status = 'cancelled';
            await order.save({ session: mongoSession });
          });
        } finally {
          mongoSession.endSession();
        }
      }
      break;
    }

    default:
      break; // ignore events we don't care about
  }

  res.json({ received: true });
};

module.exports = { handleStripeWebhook };
