const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');

// @route GET /api/products?keyword=&category=&minPrice=&maxPrice=&page=&limit=&sort=
const getProducts = asyncHandler(async (req, res) => {
  const { keyword, category, minPrice, maxPrice, page = 1, limit = 12, sort = '-createdAt' } = req.query;

  const match = { isActive: true };
  if (category) match.category = category;
  if (minPrice || maxPrice) {
    match.price = {};
    if (minPrice) match.price.$gte = Number(minPrice);
    if (maxPrice) match.price.$lte = Number(maxPrice);
  }
  if (keyword) match.$text = { $search: keyword };

  const pipeline = [
    { $match: match },
    { $lookup: { from: 'categories', localField: 'category', foreignField: '_id', as: 'category' } },
    { $unwind: '$category' },
  ];

  const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
  const sortDir = sort.startsWith('-') ? -1 : 1;
  pipeline.push({ $sort: { [sortField]: sortDir } });

  pipeline.push({
    $facet: {
      data: [{ $skip: (Number(page) - 1) * Number(limit) }, { $limit: Number(limit) }],
      totalCount: [{ $count: 'count' }],
    },
  });

  const result = await Product.aggregate(pipeline);
  const products = result[0].data;
  const total = result[0].totalCount[0]?.count || 0;

  res.json({ products, page: Number(page), totalPages: Math.ceil(total / Number(limit)), totalResults: total });
});

const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate('category', 'name slug');
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  res.json(product);
});

// @route POST /api/products   (admin only)
const createProduct = asyncHandler(async (req, res) => {
  const product = await Product.create(req.body);
  res.status(201).json(product);
});

// @route PUT /api/products/:id   (admin only)
const updateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  res.json(product);
});

// @route DELETE /api/products/:id   (admin only) — soft delete so past orders keep valid references
const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  res.json({ message: 'Product deactivated' });
});

// @route GET /api/products/admin/all   (admin only — includes inactive, for inventory management)
const getAllProductsAdmin = asyncHandler(async (req, res) => {
  const products = await Product.find().populate('category', 'name').sort('-createdAt');
  res.json(products);
});

module.exports = {
  getProducts, getProductById, createProduct, updateProduct, deleteProduct, getAllProductsAdmin,
};
