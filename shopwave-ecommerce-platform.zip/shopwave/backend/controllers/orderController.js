const asyncHandler = require('express-async-handler');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const Order = require('../models/Order');
const stripe = require('../config/stripe');

/**
 * INVENTORY CONCURRENCY STRATEGY
 * -------------------------------
 * The naive approach — read stock, check in JS, then write — has a race:
 * two customers can both read "stock: 1", both pass the check, and both buy
 * the same last unit before either write lands.
 *
 * Instead, stock is RESERVED (decremented) atomically at checkout time,
 * before Stripe is even involved, using findOneAndUpdate with a $gte guard:
 * MongoDB only applies the update if the stock condition is still true at
 * the moment the write executes, so exactly one of two racing requests wins.
 *
 * All items in an order are reserved inside a single Mongo transaction, so
 * either the whole cart succeeds or none of it does — no partial holds.
 * If checkout doesn't complete (Stripe session expires, card fails), the
 * webhook releases the reserved stock back (see webhookController.js).
 *
 * Note: transactions require MongoDB to be running as a replica set.
 * MongoDB Atlas (including the free tier) does this by default. For local
 * development, run `mongod --replSet rs0` and initiate it once with
 * `rs.initiate()` in the mongo shell.
 */
const reserveStock = async (items, session) => {
  const reserved = [];
  for (const { productId, quantity } of items) {
    const updated = await Product.findOneAndUpdate(
      { _id: productId, stock: { $gte: quantity }, isActive: true },
      { $inc: { stock: -quantity } },
      { new: true, session }
    );
    if (!updated) {
      throw new Error(`Insufficient stock for one of the items in your cart. Please refresh and try again.`);
    }
    reserved.push(updated);
  }
  return reserved;
};

const releaseStock = async (items, session) => {
  for (const item of items) {
    await Product.findByIdAndUpdate(
      item.product,
      { $inc: { stock: item.quantity } },
      { session }
    );
  }
};

// @route POST /api/orders/checkout
// body: { items: [{ productId, quantity }], shippingAddress }
const createCheckoutSession = asyncHandler(async (req, res) => {
  const { items, shippingAddress } = req.body;
  if (!items || items.length === 0) {
    res.status(400);
    throw new Error('Cart is empty');
  }

  const session = await mongoose.startSession();
  let order;

  try {
    await session.withTransaction(async () => {
      const products = await reserveStock(items, session);

      const orderItems = products.map((p, i) => ({
        product: p._id,
        name: p.name,
        price: p.price,
        quantity: items[i].quantity,
      }));
      const subtotal = orderItems.reduce((sum, it) => sum + it.price * it.quantity, 0);

      order = await Order.create(
        [{ user: req.user._id, items: orderItems, subtotal, shippingAddress, status: 'pending_payment' }],
        { session }
      );
      order = order[0];
    });
  } catch (err) {
    res.status(409); // Conflict — most likely an out-of-stock race
    throw new Error(err.message);
  } finally {
    session.endSession();
  }

  // Stripe Checkout Session — test mode. Card number 4242 4242 4242 4242, any future date/CVC.
  const stripeSession = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: order.items.map((item) => ({
      price_data: {
        currency: 'usd',
        product_data: { name: item.name },
        unit_amount: Math.round(item.price * 100), // Stripe expects cents
      },
      quantity: item.quantity,
    })),
    metadata: { orderId: order._id.toString() },
    success_url: `${process.env.CLIENT_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.CLIENT_URL}/checkout/cancel`,
  });

  order.stripeSessionId = stripeSession.id;
  await order.save();

  res.status(201).json({ checkoutUrl: stripeSession.url, orderId: order._id });
});

// @route GET /api/orders/mine
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort('-createdAt');
  res.json(orders);
});

// @route GET /api/orders/:id
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('user', 'name email');
  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }
  const isOwner = order.user._id.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to view this order');
  }
  res.json(order);
});

// @route GET /api/orders   (admin only — all orders, paginated)
const getAllOrders = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const match = {};
  if (status) match.status = status;

  const orders = await Order.find(match)
    .populate('user', 'name email')
    .sort('-createdAt')
    .skip((Number(page) - 1) * Number(limit))
    .limit(Number(limit));
  const total = await Order.countDocuments(match);

  res.json({ orders, page: Number(page), totalPages: Math.ceil(total / Number(limit)), totalResults: total });
});

// @route PUT /api/orders/:id/status   (admin only — for shipped/delivered; paid/cancelled come from webhooks)
const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['shipped', 'delivered'].includes(status)) {
    res.status(400);
    throw new Error('Admins can only manually set status to shipped or delivered');
  }
  const order = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true });
  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }
  res.json(order);
});

module.exports = {
  createCheckoutSession, getMyOrders, getOrderById, getAllOrders, updateOrderStatus, releaseStock,
};
