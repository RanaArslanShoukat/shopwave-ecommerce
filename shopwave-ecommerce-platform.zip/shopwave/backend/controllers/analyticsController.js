const asyncHandler = require('express-async-handler');
const Order = require('../models/Order');
const Product = require('../models/Product');

// @route GET /api/analytics/revenue?days=30
// Revenue and order count per day, for a line chart.
const getRevenueOverTime = asyncHandler(async (req, res) => {
  const days = Number(req.query.days) || 30;
  const since = new Date();
  since.setDate(since.getDate() - days);

  const data = await Order.aggregate([
    { $match: { status: { $in: ['paid', 'shipped', 'delivered'] }, createdAt: { $gte: since } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        revenue: { $sum: '$subtotal' },
        orders: { $sum: 1 },
      },
    },
    { $sort: { _id: 1 } },
    { $project: { _id: 0, date: '$_id', revenue: 1, orders: 1 } },
  ]);

  res.json(data);
});

// @route GET /api/analytics/top-products?limit=5
const getTopProducts = asyncHandler(async (req, res) => {
  const limit = Number(req.query.limit) || 5;
  const products = await Product.find({ unitsSold: { $gt: 0 } })
    .sort('-unitsSold')
    .limit(limit)
    .select('name unitsSold price');
  res.json(products);
});

// @route GET /api/analytics/order-status-breakdown
const getOrderStatusBreakdown = asyncHandler(async (req, res) => {
  const data = await Order.aggregate([
    { $group: { _id: '$status', count: { $sum: 1 } } },
    { $project: { _id: 0, status: '$_id', count: 1 } },
  ]);
  res.json(data);
});

// @route GET /api/analytics/summary
const getSummary = asyncHandler(async (req, res) => {
  const [revenueResult] = await Order.aggregate([
    { $match: { status: { $in: ['paid', 'shipped', 'delivered'] } } },
    { $group: { _id: null, totalRevenue: { $sum: '$subtotal' }, totalOrders: { $sum: 1 } } },
  ]);
  const lowStockCount = await Product.countDocuments({ isActive: true, stock: { $lte: 5 } });

  res.json({
    totalRevenue: revenueResult?.totalRevenue || 0,
    totalOrders: revenueResult?.totalOrders || 0,
    lowStockCount,
  });
});

module.exports = { getRevenueOverTime, getTopProducts, getOrderStatusBreakdown, getSummary };
