const express = require('express');
const router = express.Router();
const {
  getRevenueOverTime, getTopProducts, getOrderStatusBreakdown, getSummary,
} = require('../controllers/analyticsController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.use(protect, requireRole('admin'));
router.get('/summary', getSummary);
router.get('/revenue', getRevenueOverTime);
router.get('/top-products', getTopProducts);
router.get('/order-status-breakdown', getOrderStatusBreakdown);

module.exports = router;
