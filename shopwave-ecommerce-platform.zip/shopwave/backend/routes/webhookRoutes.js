const express = require('express');
const router = express.Router();
const { handleStripeWebhook } = require('../controllers/webhookController');

// NOTE: express.raw (not express.json) is applied to this route specifically
// in server.js, before the global express.json() middleware — Stripe's
// signature check needs the exact raw bytes of the request body.
router.post('/stripe', handleStripeWebhook);

module.exports = router;
