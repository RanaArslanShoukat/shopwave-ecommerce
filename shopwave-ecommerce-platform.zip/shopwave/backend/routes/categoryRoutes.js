const express = require('express');
const router = express.Router();
const { getCategories, createCategory } = require('../controllers/categoryController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.get('/', getCategories);
router.post('/', protect, requireRole('admin'), createCategory);

module.exports = router;
