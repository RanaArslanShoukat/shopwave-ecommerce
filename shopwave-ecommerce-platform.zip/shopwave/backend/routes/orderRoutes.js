const express = require('express');
const router = express.Router();
const {
  createCheckoutSession, getMyOrders, getOrderById, getAllOrders, updateOrderStatus,
} = require('../controllers/orderController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.post('/checkout', protect, createCheckoutSession);
router.get('/mine', protect, getMyOrders);
router.get('/', protect, requireRole('admin'), getAllOrders);
router.get('/:id', protect, getOrderById);
router.put('/:id/status', protect, requireRole('admin'), updateOrderStatus);

module.exports = router;
