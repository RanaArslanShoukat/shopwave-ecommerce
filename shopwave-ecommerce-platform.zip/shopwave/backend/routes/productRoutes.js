const express = require('express');
const router = express.Router();
const {
  getProducts, getProductById, createProduct, updateProduct, deleteProduct, getAllProductsAdmin,
} = require('../controllers/productController');
const { protect } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');

router.get('/', getProducts);
router.get('/admin/all', protect, requireRole('admin'), getAllProductsAdmin);
router.get('/:id', getProductById);
router.post('/', protect, requireRole('admin'), createProduct);
router.put('/:id', protect, requireRole('admin'), updateProduct);
router.delete('/:id', protect, requireRole('admin'), deleteProduct);

module.exports = router;
