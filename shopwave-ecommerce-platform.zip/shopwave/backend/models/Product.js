const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    description: { type: String, required: true },
    price: { type: Number, required: true, min: 0 }, // stored in dollars; converted to cents for Stripe
    imageUrl: { type: String, default: '' },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true, index: true },
    // stock is the field every concurrency-safe update below touches atomically —
    // never read-then-write this in JS; always use $inc with a $gte guard (see orderController).
    stock: { type: Number, required: true, min: 0, default: 0 },
    sku: { type: String, unique: true, sparse: true },
    isActive: { type: Boolean, default: true },
    // Denormalized counter, updated whenever an order is marked 'paid' — powers
    // the admin "top products" chart without an aggregation over the whole Order collection.
    unitsSold: { type: Number, default: 0 },
  },
  { timestamps: true }
);

productSchema.index({ name: 'text', description: 'text' });

module.exports = mongoose.model('Product', productSchema);
