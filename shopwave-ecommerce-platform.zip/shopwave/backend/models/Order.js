const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name: { type: String, required: true }, // snapshot at time of order, in case product changes later
    price: { type: Number, required: true }, // snapshot price per unit, in dollars
    quantity: { type: Number, required: true, min: 1 },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    items: [orderItemSchema],
    subtotal: { type: Number, required: true },
    // Order lifecycle:
    //   pending_payment -> stock has been RESERVED (decremented), waiting on Stripe
    //   paid            -> Stripe webhook confirmed payment; unitsSold incremented
    //   cancelled        -> checkout expired/failed; stock has been RELEASED back
    //   shipped / delivered -> set manually by admin after payment
    status: {
      type: String,
      enum: ['pending_payment', 'paid', 'cancelled', 'shipped', 'delivered'],
      default: 'pending_payment',
      index: true,
    },
    stripeSessionId: { type: String, index: true },
    stripePaymentIntentId: { type: String },
    shippingAddress: {
      line1: String, city: String, state: String, postalCode: String, country: String,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Order', orderSchema);
