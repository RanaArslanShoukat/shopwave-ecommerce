const requireRole = (...allowedRoles) => (req, res, next) => {
  if (!req.user || !allowedRoles.includes(req.user.role)) {
    res.status(403);
    return next(new Error(`Access denied. Requires role: ${allowedRoles.join(' or ')}`));
  }
  next();
};

module.exports = { requireRole };
