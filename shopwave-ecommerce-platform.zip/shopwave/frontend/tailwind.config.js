/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        accent: {
          50: '#fff7ed', 100: '#ffedd5', 400: '#fb923c', 500: '#f97316', 600: '#ea580c', 700: '#c2410c',
        },
        ink: { 900: '#0a0a0a', 700: '#3f3f46' },
      },
      fontFamily: { display: ['"Space Grotesk"', 'sans-serif'] },
    },
  },
  plugins: [],
};
