import { NavLink, Outlet } from 'react-router-dom';

const linkClass = ({ isActive }) =>
  `block px-4 py-2.5 rounded-lg text-sm ${isActive ? 'bg-ink-900 text-white' : 'text-gray-600 hover:bg-gray-100'}`;

const AdminLayout = () => (
  <div className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-4 gap-6">
    <aside className="col-span-1 space-y-1">
      <NavLink to="/admin" end className={linkClass}>Dashboard</NavLink>
      <NavLink to="/admin/products" className={linkClass}>Products</NavLink>
      <NavLink to="/admin/orders" className={linkClass}>Orders</NavLink>
    </aside>
    <div className="col-span-3">
      <Outlet />
    </div>
  </div>
);

export default AdminLayout;
