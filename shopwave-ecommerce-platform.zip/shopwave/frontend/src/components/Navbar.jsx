import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { items } = useCart();
  const navigate = useNavigate();
  const cartCount = items.reduce((n, i) => n + i.quantity, 0);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <nav className="bg-ink-900 text-white sticky top-0 z-10">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="font-bold text-xl tracking-tight flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-accent-500"></span>
          Shopwave
        </Link>
        <div className="flex items-center gap-6 text-sm">
          <Link to="/" className="text-gray-300 hover:text-white transition">Shop</Link>
          <Link to="/orders" className="text-gray-300 hover:text-white transition">Orders</Link>
          <Link to="/cart" className="relative text-gray-300 hover:text-white transition">
            Cart
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-3 bg-accent-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Link>
          {user?.role === 'admin' && (
            <Link to="/admin" className="text-accent-400 hover:text-accent-300 transition font-medium">Admin</Link>
          )}
          {user ? (
            <button onClick={handleLogout} className="text-gray-300 hover:text-white transition">Logout</button>
          ) : (
            <Link to="/login" className="bg-accent-500 hover:bg-accent-600 px-4 py-1.5 rounded-full transition">
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
