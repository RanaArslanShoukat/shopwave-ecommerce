import { Link } from 'react-router-dom';

const ProductCard = ({ product }) => (
  <Link to={`/products/${product._id}`} className="group block">
    <div className="aspect-square bg-gray-100 rounded-2xl overflow-hidden mb-3 flex items-center justify-center">
      {product.imageUrl ? (
        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
      ) : (
        <span className="text-gray-300 text-sm">No image</span>
      )}
    </div>
    <div className="flex justify-between items-start">
      <div>
        <p className="font-medium text-ink-900">{product.name}</p>
        <p className="text-xs text-gray-400">{product.category?.name}</p>
      </div>
      <p className="font-semibold text-accent-600">${product.price.toFixed(2)}</p>
    </div>
    {product.stock <= 5 && product.stock > 0 && (
      <p className="text-xs text-amber-600 mt-1">Only {product.stock} left</p>
    )}
    {product.stock === 0 && <p className="text-xs text-red-500 mt-1">Out of stock</p>}
  </Link>
);

export default ProductCard;
