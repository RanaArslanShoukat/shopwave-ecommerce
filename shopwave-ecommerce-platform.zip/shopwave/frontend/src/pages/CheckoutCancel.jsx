import { Link } from 'react-router-dom';

const CheckoutCancel = () => (
  <div className="max-w-md mx-auto px-4 py-24 text-center">
    <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-2xl">!</div>
    <h1 className="text-xl font-bold mt-4">Checkout cancelled</h1>
    <p className="text-gray-500 mt-2 text-sm">No payment was taken. Your reserved items will be released automatically.</p>
    <Link to="/cart" className="inline-block mt-6 bg-ink-900 text-white px-5 py-2.5 rounded-full text-sm">Back to Cart</Link>
  </div>
);

export default CheckoutCancel;
