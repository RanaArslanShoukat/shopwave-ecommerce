import { useEffect, useState } from 'react';
import api from '../../api/axios';

const emptyForm = { name: '', description: '', price: '', category: '', stock: '', sku: '', imageUrl: '' };

const AdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const fetchProducts = () => api.get('/products/admin/all').then((res) => setProducts(res.data));

  useEffect(() => {
    fetchProducts();
    api.get('/categories').then((res) => setCategories(res.data));
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = { ...form, price: Number(form.price), stock: Number(form.stock) };
    if (editingId) {
      await api.put(`/products/${editingId}`, payload);
    } else {
      await api.post('/products', payload);
    }
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    fetchProducts();
  };

  const handleEdit = (p) => {
    setForm({
      name: p.name, description: p.description, price: p.price,
      category: p.category?._id || '', stock: p.stock, sku: p.sku || '', imageUrl: p.imageUrl || '',
    });
    setEditingId(p._id);
    setShowForm(true);
  };

  const handleDeactivate = async (id) => {
    await api.delete(`/products/${id}`);
    fetchProducts();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold">Products</h1>
        <button onClick={() => { setForm(emptyForm); setEditingId(null); setShowForm(!showForm); }}
          className="bg-ink-900 text-white px-4 py-2 rounded-lg text-sm">
          {showForm ? 'Cancel' : '+ Add Product'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white border border-gray-100 rounded-xl p-5 mb-6 grid grid-cols-2 gap-3">
          <input name="name" placeholder="Name" value={form.name} required onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm col-span-2" />
          <textarea name="description" placeholder="Description" value={form.description} required onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm col-span-2" rows={2} />
          <input name="price" type="number" step="0.01" placeholder="Price" value={form.price} required onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input name="stock" type="number" placeholder="Stock" value={form.stock} required onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <select name="category" value={form.category} required onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm">
            <option value="">Select category</option>
            {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
          <input name="sku" placeholder="SKU (optional)" value={form.sku} onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input name="imageUrl" placeholder="Image URL (optional)" value={form.imageUrl} onChange={handleChange}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm col-span-2" />
          <button className="bg-accent-500 text-white py-2 rounded-lg text-sm col-span-2">
            {editingId ? 'Update Product' : 'Create Product'}
          </button>
        </form>
      )}

      <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
              <th className="text-left px-4 py-3">Name</th>
              <th className="text-left px-4 py-3">Category</th>
              <th className="text-left px-4 py-3">Price</th>
              <th className="text-left px-4 py-3">Stock</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="text-left px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p._id} className="border-t border-gray-100">
                <td className="px-4 py-3 font-medium">{p.name}</td>
                <td className="px-4 py-3 text-gray-500">{p.category?.name}</td>
                <td className="px-4 py-3">${p.price.toFixed(2)}</td>
                <td className={`px-4 py-3 ${p.stock <= 5 ? 'text-amber-600 font-medium' : ''}`}>{p.stock}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${p.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {p.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3 space-x-2">
                  <button onClick={() => handleEdit(p)} className="text-accent-600 text-xs">Edit</button>
                  {p.isActive && <button onClick={() => handleDeactivate(p._id)} className="text-red-500 text-xs">Deactivate</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminProducts;
