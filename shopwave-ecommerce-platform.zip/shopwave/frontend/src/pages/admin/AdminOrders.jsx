import { useEffect, useState } from 'react';
import api from '../../api/axios';

const statusColor = (s) => ({
  pending_payment: 'bg-amber-100 text-amber-700',
  paid: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
}[s] || 'bg-gray-100 text-gray-600');

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');

  const fetchOrders = () => {
    const params = statusFilter ? { status: statusFilter } : {};
    api.get('/orders', { params }).then((res) => setOrders(res.data.orders));
  };

  useEffect(() => { fetchOrders(); }, [statusFilter]); // eslint-disable-line

  const advanceStatus = async (order) => {
    const next = order.status === 'paid' ? 'shipped' : order.status === 'shipped' ? 'delivered' : null;
    if (!next) return;
    await api.put(`/orders/${order._id}/status`, { status: next });
    fetchOrders();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold">Orders</h1>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm">
          <option value="">All statuses</option>
          <option value="pending_payment">Pending Payment</option>
          <option value="paid">Paid</option>
          <option value="shipped">Shipped</option>
          <option value="delivered">Delivered</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      <div className="space-y-3">
        {orders.map((o) => (
          <div key={o._id} className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium text-sm">#{o._id.slice(-6)} — {o.user?.name} ({o.user?.email})</p>
                <p className="text-xs text-gray-400 mt-0.5">{new Date(o.createdAt).toLocaleString()}</p>
              </div>
              <span className={`text-xs px-3 py-1 rounded-full capitalize font-medium ${statusColor(o.status)}`}>
                {o.status.replace('_', ' ')}
              </span>
            </div>
            <div className="mt-3 text-sm space-y-0.5">
              {o.items.map((item, i) => (
                <p key={i}>{item.quantity} × {item.name}</p>
              ))}
            </div>
            <div className="flex justify-between items-center mt-3">
              <p className="font-semibold text-sm">${o.subtotal.toFixed(2)}</p>
              {['paid', 'shipped'].includes(o.status) && (
                <button onClick={() => advanceStatus(o)} className="text-xs bg-ink-900 text-white px-3 py-1.5 rounded-lg">
                  Mark as {o.status === 'paid' ? 'Shipped' : 'Delivered'}
                </button>
              )}
            </div>
          </div>
        ))}
        {orders.length === 0 && <p className="text-gray-400 text-sm">No orders match this filter.</p>}
      </div>
    </div>
  );
};

export default AdminOrders;
