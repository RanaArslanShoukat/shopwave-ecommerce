import { useEffect, useState } from 'react';
import api from '../api/axios';

const statusColor = (s) => ({
  pending_payment: 'bg-amber-100 text-amber-700',
  paid: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
}[s] || 'bg-gray-100 text-gray-600');

const Orders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => { api.get('/orders/mine').then((res) => setOrders(res.data)); }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-xl font-bold mb-6">Your Orders</h1>
      {orders.length === 0 && <p className="text-gray-400 text-sm">No orders yet.</p>}
      <div className="space-y-3">
        {orders.map((o) => (
          <div key={o._id} className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-400">Order #{o._id.slice(-6)} · {new Date(o.createdAt).toLocaleDateString()}</p>
              <span className={`text-xs px-3 py-1 rounded-full capitalize font-medium ${statusColor(o.status)}`}>
                {o.status.replace('_', ' ')}
              </span>
            </div>
            <div className="mt-3 space-y-1">
              {o.items.map((item, i) => (
                <p key={i} className="text-sm">{item.quantity} × {item.name} — ${(item.price * item.quantity).toFixed(2)}</p>
              ))}
            </div>
            <p className="mt-3 font-semibold text-sm">Total: ${o.subtotal.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;
