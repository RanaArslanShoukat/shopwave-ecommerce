import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api/axios';
import { useCart } from '../context/CartContext';

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();

  useEffect(() => { api.get(`/products/${id}`).then((res) => setProduct(res.data)); }, [id]);

  if (!product) return <p className="p-8 text-center text-gray-400">Loading...</p>;

  const handleAdd = () => {
    addItem(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 grid md:grid-cols-2 gap-10">
      <div className="aspect-square bg-gray-100 rounded-2xl overflow-hidden flex items-center justify-center">
        {product.imageUrl ? (
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
        ) : (
          <span className="text-gray-300">No image</span>
        )}
      </div>
      <div>
        <p className="text-xs text-gray-400 uppercase tracking-wide">{product.category?.name}</p>
        <h1 className="text-2xl font-bold mt-1">{product.name}</h1>
        <p className="text-2xl font-semibold text-accent-600 mt-3">${product.price.toFixed(2)}</p>
        <p className="text-gray-600 mt-4">{product.description}</p>

        {product.stock > 0 ? (
          <>
            <p className="text-sm text-gray-400 mt-4">{product.stock} in stock</p>
            <div className="flex items-center gap-3 mt-4">
              <input type="number" min="1" max={product.stock} value={quantity}
                onChange={(e) => setQuantity(Math.max(1, Math.min(product.stock, Number(e.target.value))))}
                className="w-16 border border-gray-200 rounded-lg px-2 py-2 text-sm text-center" />
              <button onClick={handleAdd} className="bg-ink-900 text-white px-6 py-2.5 rounded-full text-sm hover:bg-ink-700 transition">
                {added ? 'Added!' : 'Add to Cart'}
              </button>
            </div>
          </>
        ) : (
          <p className="text-red-500 mt-4 font-medium">Out of stock</p>
        )}

        <Link to="/cart" className="block text-sm text-accent-600 mt-4">View cart &rarr;</Link>
      </div>
    </div>
  );
};

export default ProductDetail;
