import { useEffect, useState } from 'react';
import api from '../api/axios';
import ProductCard from '../components/ProductCard';

const Home = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({ keyword: '', category: '', minPrice: '', maxPrice: '' });
  const [page, setPage] = useState(1);
  const [meta, setMeta] = useState({ totalPages: 1, totalResults: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => { api.get('/categories').then((res) => setCategories(res.data)); }, []);

  const fetchProducts = async () => {
    setLoading(true);
    const params = { ...filters, page, limit: 8 };
    Object.keys(params).forEach((k) => !params[k] && delete params[k]);
    const { data } = await api.get('/products', { params });
    setProducts(data.products);
    setMeta({ totalPages: data.totalPages, totalResults: data.totalResults });
    setLoading(false);
  };

  useEffect(() => { fetchProducts(); }, [page]); // eslint-disable-line

  const handleSearch = (e) => { e.preventDefault(); setPage(1); fetchProducts(); };

  return (
    <div>
      <div className="bg-gradient-to-br from-ink-900 to-ink-700 text-white">
        <div className="max-w-6xl mx-auto px-4 py-16">
          <h1 className="text-4xl font-bold tracking-tight max-w-lg">Thoughtfully made goods, delivered fast.</h1>
          <p className="text-gray-300 mt-3 max-w-md">Browse the collection below — every order ships within 2 business days.</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-10">
        <form onSubmit={handleSearch} className="flex flex-wrap gap-3 mb-8">
          <input placeholder="Search products..." value={filters.keyword}
            onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
            className="border border-gray-200 rounded-full px-4 py-2 text-sm flex-1 min-w-[180px]" />
          <select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            className="border border-gray-200 rounded-full px-4 py-2 text-sm">
            <option value="">All categories</option>
            {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
          <input placeholder="Min $" type="number" value={filters.minPrice}
            onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
            className="border border-gray-200 rounded-full px-4 py-2 text-sm w-24" />
          <input placeholder="Max $" type="number" value={filters.maxPrice}
            onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
            className="border border-gray-200 rounded-full px-4 py-2 text-sm w-24" />
          <button className="bg-ink-900 text-white px-5 py-2 rounded-full text-sm">Search</button>
        </form>

        {loading ? (
          <p className="text-gray-400">Loading products...</p>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {products.map((p) => <ProductCard key={p._id} product={p} />)}
            </div>
            <div className="flex justify-center items-center gap-4 mt-10 text-sm">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1.5 border rounded-full disabled:opacity-40">Prev</button>
              <span className="text-gray-400">Page {page} of {meta.totalPages || 1}</span>
              <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1.5 border rounded-full disabled:opacity-40">Next</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Home;
