import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

// The actual order confirmation (status: paid) happens server-side via the
// Stripe webhook, not here — this page just clears the local cart and
// reassures the customer. Don't trust this page alone to mean "paid";
// check the order's status via GET /api/orders/:id if you need certainty.
const CheckoutSuccess = () => {
  const { clearCart } = useCart();
  useEffect(() => { clearCart(); }, []); // eslint-disable-line

  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <div className="w-14 h-14 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto text-2xl">✓</div>
      <h1 className="text-xl font-bold mt-4">Payment received!</h1>
      <p className="text-gray-500 mt-2 text-sm">Your order is confirmed. You'll see it under Orders once Stripe finishes processing.</p>
      <Link to="/orders" className="inline-block mt-6 bg-ink-900 text-white px-5 py-2.5 rounded-full text-sm">View Orders</Link>
    </div>
  );
};

export default CheckoutSuccess;
