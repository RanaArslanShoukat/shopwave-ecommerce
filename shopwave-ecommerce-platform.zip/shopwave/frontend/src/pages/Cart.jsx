import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

const Cart = () => {
  const { items, updateQuantity, removeItem, subtotal } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [address, setAddress] = useState({ line1: '', city: '', state: '', postalCode: '', country: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCheckout = async () => {
    if (!user) return navigate('/login');
    setError('');
    setLoading(true);
    try {
      const payload = {
        items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        shippingAddress: address,
      };
      const { data } = await api.post('/orders/checkout', payload);
      window.location.href = data.checkoutUrl; // redirect to Stripe Checkout
    } catch (err) {
      setError(err.response?.data?.message || 'Checkout failed — please try again.');
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="text-gray-400">Your cart is empty.</p>
        <Link to="/" className="text-accent-600 text-sm mt-2 inline-block">Continue shopping &rarr;</Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <h1 className="text-xl font-bold mb-6">Your Cart</h1>
      <div className="space-y-3 mb-8">
        {items.map((item) => (
          <div key={item.productId} className="flex justify-between items-center bg-white border border-gray-100 rounded-xl p-4">
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-sm text-gray-400">${item.price.toFixed(2)} each</p>
            </div>
            <div className="flex items-center gap-3">
              <input type="number" min="1" value={item.quantity}
                onChange={(e) => updateQuantity(item.productId, Number(e.target.value))}
                className="w-14 border border-gray-200 rounded-lg px-2 py-1.5 text-sm text-center" />
              <button onClick={() => removeItem(item.productId)} className="text-red-500 text-xs">Remove</button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-gray-100 rounded-xl p-5 mb-6">
        <h2 className="font-medium mb-3 text-sm">Shipping Address</h2>
        <div className="grid grid-cols-2 gap-3">
          <input placeholder="Address line" value={address.line1} onChange={(e) => setAddress({ ...address, line1: e.target.value })}
            className="col-span-2 border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="City" value={address.city} onChange={(e) => setAddress({ ...address, city: e.target.value })}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="State" value={address.state} onChange={(e) => setAddress({ ...address, state: e.target.value })}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Postal code" value={address.postalCode} onChange={(e) => setAddress({ ...address, postalCode: e.target.value })}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Country" value={address.country} onChange={(e) => setAddress({ ...address, country: e.target.value })}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
        </div>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      <div className="flex justify-between items-center">
        <p className="text-lg font-semibold">Subtotal: ${subtotal.toFixed(2)}</p>
        <button onClick={handleCheckout} disabled={loading}
          className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-3 rounded-full text-sm font-medium disabled:opacity-60">
          {loading ? 'Redirecting to Stripe...' : 'Checkout with Stripe'}
        </button>
      </div>
    </div>
  );
};

export default Cart;
