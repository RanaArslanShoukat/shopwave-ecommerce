import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const user = await login(email, password);
      navigate(user.role === 'admin' ? '/admin' : '/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="max-w-sm mx-auto mt-16 bg-white p-8 rounded-2xl border border-gray-100 shadow-sm">
      <h1 className="text-xl font-bold mb-1">Welcome back</h1>
      <p className="text-sm text-gray-400 mb-6">Log in to Shopwave</p>
      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input type="email" placeholder="Email" value={email} required onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm" />
        <input type="password" placeholder="Password" value={password} required onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm" />
        <button className="w-full bg-ink-900 text-white py-2.5 rounded-full text-sm hover:bg-ink-700 transition">Log in</button>
      </form>
      <p className="text-xs text-gray-400 mt-4">
        Seeded accounts — admin@example.com / admin123, or customer@example.com / customer123
      </p>
      <p className="text-sm text-gray-500 mt-3">
        No account? <Link to="/register" className="text-accent-600 font-medium">Sign up</Link>
      </p>
    </div>
  );
};

export default Login;
