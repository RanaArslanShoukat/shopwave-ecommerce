import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await register(form);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div className="max-w-sm mx-auto mt-16 bg-white p-8 rounded-2xl border border-gray-100 shadow-sm">
      <h1 className="text-xl font-bold mb-6">Create your account</h1>
      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="name" placeholder="Full name" value={form.name} required onChange={handleChange}
          className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm" />
        <input name="email" type="email" placeholder="Email" value={form.email} required onChange={handleChange}
          className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm" />
        <input name="password" type="password" placeholder="Password (min 6 chars)" value={form.password} required minLength={6}
          onChange={handleChange} className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm" />
        <button className="w-full bg-ink-900 text-white py-2.5 rounded-full text-sm hover:bg-ink-700 transition">Create account</button>
      </form>
      <p className="text-sm text-gray-500 mt-4">
        Already have an account? <Link to="/login" className="text-accent-600 font-medium">Log in</Link>
      </p>
    </div>
  );
};

export default Register;
